
███╗   ██╗██╗ ██████╗██╗  ██╗███████╗██╗        ███████╗██╗  ██╗███████╗
████╗  ██║██║██╔════╝██║ ██╔╝██╔════╝██║        ██╔════╝╚██╗██╔╝██╔════╝
██╔██╗ ██║██║██║     █████╔╝ █████╗  ██║        █████╗   ╚███╔╝ █████╗  
██║╚██╗██║██║██║     ██╔═██╗ ██╔══╝  ██║        ██╔══╝   ██╔██╗ ██╔══╝  
██║ ╚████║██║╚██████╗██║  ██╗███████╗███████╗██╗███████╗██╔╝ ██╗███████╗
╚═╝  ╚═══╝╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚══════╝╚═╝╚══════╝╚═╝  ╚═╝╚══════╝
                                                                        
Malware name: Nickel.exe
Malware type: Destroy
By: Nyfol2290
Description: This is a skidded malware for you, this is a Win32.Kill.Trojan, It blocks the task manager and also changes the name of the windows to nickel.exe